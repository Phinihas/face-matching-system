from typing import List
from .types import PairResult, ThresholdResult
from .metrics import calculate_metrics
from .config import THRESHOLD_RANGE
from .logger import get_evaluation_logger

logger = get_evaluation_logger("threshold")

def evaluate_thresholds(results: List[PairResult]) -> List[ThresholdResult]:
    """Evaluates metrics across a range of thresholds."""
    if not results:
        return []
        
    logger.info(f"Evaluating thresholds from {min(THRESHOLD_RANGE)} to {max(THRESHOLD_RANGE)}")
    threshold_results = []
    
    for t in THRESHOLD_RANGE:
        metrics = calculate_metrics(results, threshold=t)
        
        threshold_results.append(ThresholdResult(
            threshold=t,
            accuracy=metrics.accuracy,
            precision=metrics.precision,
            recall=metrics.recall,
            f1=metrics.f1_score,
            far=metrics.false_acceptance_rate,
            frr=metrics.false_rejection_rate,
            eer=metrics.equal_error_rate
        ))
        
    return threshold_results

def find_best_thresholds(threshold_results: List[ThresholdResult]) -> dict:
    """Finds best thresholds for Accuracy, F1, and EER."""
    if not threshold_results:
        return {}
        
    best_acc = max(threshold_results, key=lambda x: x['accuracy'])
    best_f1 = max(threshold_results, key=lambda x: x['f1'])
    best_eer = min(threshold_results, key=lambda x: abs(x['eer'] - x['far'])) # Approximate point where FAR == FRR
    
    return {
        "best_accuracy": best_acc['threshold'],
        "best_f1": best_f1['threshold'],
        "lowest_eer": best_eer['threshold']
    }
